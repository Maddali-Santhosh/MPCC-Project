#ifndef CLIENT_H
#define CLIENT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/select.h>

#define PORT 9091
#define BUFFER_SIZE 1024
#define MAX_CREDENTIALS 256
#define XOR_KEY 0x5A

void encrypt_decrypt(char *data);
void register_user();
int authenticate_user(const char *username, const char *password);
//void client_chat(int sockfd);

#endif
