#ifndef SERVER_H
#define SERVER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <time.h>

#define PORT 9091
#define BUFFER_SIZE 1024
#define MAX_CLIENTS 10
#define XOR_KEY 0x5A

void encrypt_decrypt(char *data);
void get_current_time(char* buffer);
void log_server_activity(const char* message);
//void handle_client_message(int client_socket, int client_id, int client_sockets[], int client_ids[], fd_set *master_fds, int max_clients);
//void accept_new_client(int server_fd, int client_sockets[], int client_ids[], fd_set *master_fds, int *max_fd, int *next_client_id);

#endif
