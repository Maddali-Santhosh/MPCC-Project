#include "server.h"


// Function to encrypt and decrypt data using XOR operation
void encrypt_decrypt(char *data) {
    for (int i = 0; i < strlen(data); i++) {
        data[i] ^= XOR_KEY;
    }
}

void get_current_time(char* buffer) {
    time_t rawtime;
    struct tm *timeinfo;
    time(&rawtime);
    timeinfo = localtime(&rawtime);
    strftime(buffer, 20, "%Y-%m-%d %H:%M:%S", timeinfo);
}

void log_server_activity(const char* message) {
    FILE *logfile = fopen("server_log.txt", "a");
    if (logfile == NULL) {
        perror("Error opening log file");
        return;
    }
    char timestamp[20];
    get_current_time(timestamp);
    fprintf(logfile, "[%s] %s\n", timestamp, message);
    fclose(logfile);
}
