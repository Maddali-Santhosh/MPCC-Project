#include "client.h"

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    fd_set read_fds;  // File descriptor set for handling input/output
    char buffer[BUFFER_SIZE], username[MAX_CREDENTIALS], password[MAX_CREDENTIALS];

    while (1) {
        // Prompt user to either register or log in
        printf("1. Register\n2. Login\nChoose an option: ");
        int choice;
        scanf("%d", &choice);
        getchar(); // Consume the newline character left by scanf

        if (choice == 1) {
            register_user();
            continue; // Go back to the start of the loop to prompt again
        }

        // Prompt user for login credentials
        printf("Enter username: ");
        fgets(username, sizeof(username), stdin);
        username[strcspn(username, "\n")] = 0;  // Remove newline character
        printf("Enter password: ");
        fgets(password, sizeof(password), stdin);
        password[strcspn(password, "\n")] = 0;  // Remove newline character

        // Authenticate user before connecting to the server
        if (!authenticate_user(username, password)) {
            printf("Invalid credentials.\n");
            continue; // Go back to the start of the loop to prompt again
        }

        // Create a socket for communication
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd < 0) {
            perror("Socket creation failed");
            exit(EXIT_FAILURE);
        }

        // Configure server address
        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(PORT);
        server_addr.sin_addr.s_addr = INADDR_ANY;

        // Attempt to connect to the server
        if (connect(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
            perror("Connection failed");
            close(sockfd);
            exit(EXIT_FAILURE);
        }

        printf("Connected to chat server. Start typing...\n");

        while (1) {
            FD_ZERO(&read_fds);            // Clear the file descriptor set
            FD_SET(STDIN_FILENO, &read_fds); // Add standard input (keyboard)
            FD_SET(sockfd, &read_fds);       // Add socket for communication

            // Use select() to monitor both input and server messages
            if (select(sockfd + 1, &read_fds, NULL, NULL, NULL) < 0) {
                perror("select() error");
                exit(EXIT_FAILURE);
            }

            // If user typed a message, read and send it to the server
            if (FD_ISSET(STDIN_FILENO, &read_fds)) {
                fgets(buffer, BUFFER_SIZE, stdin);
                encrypt_decrypt(buffer);  // Encrypt message before sending
                send(sockfd, buffer, strlen(buffer), 0);
            }

            // If a message is received from the server
            if (FD_ISSET(sockfd, &read_fds)) {
                int bytes_received = recv(sockfd, buffer, BUFFER_SIZE, 0);
                if (bytes_received <= 0) {
                    printf("Server disconnected.\n");
                    close(sockfd);
                    break; // Exit the inner loop and return to the registration/login prompt
                }
                buffer[bytes_received] = '\0';
                encrypt_decrypt(buffer);  // Decrypt received message
                printf("\nMessage from chat: %s", buffer);
            }
        }

        close(sockfd); // Close the socket when the server disconnects
    }

    return 0;
}
