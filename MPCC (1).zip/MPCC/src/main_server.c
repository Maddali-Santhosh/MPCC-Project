#include "server.h"
int main() {
    int server_fd, client_fd, max_fd, client_sockets[MAX_CLIENTS] = {0};
    struct sockaddr_in server_addr, client_addr;
    fd_set read_fds, master_fds;
    socklen_t client_len = sizeof(client_addr);
    char buffer[BUFFER_SIZE];
    int client_ids[MAX_CLIENTS] = {0}; // Array to store client IDs
    int next_client_id = 1;            // Next available client ID

    // Create a socket for communication
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Configure server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind the socket to the specified address and port
    if (bind(server_fd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    // Start listening for incoming connections
    if (listen(server_fd, MAX_CLIENTS) < 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    // Initialize file descriptor set
    FD_ZERO(&master_fds);
    FD_SET(server_fd, &master_fds);
    max_fd = server_fd;

    printf("Server listening on port %d...\n", PORT);

    while (1) {
        read_fds = master_fds; // Copy master file descriptors to read set
        if (select(max_fd + 1, &read_fds, NULL, NULL, NULL) < 0) {
            perror("select() error");
            exit(EXIT_FAILURE);
        }

        // Accept new client connections
        if (FD_ISSET(server_fd, &read_fds)) {
            if ((client_fd = accept(server_fd, (struct sockaddr*)&client_addr, &client_len)) < 0) {
                perror("Accept failed");
                continue;
            }

            // Assign a unique ID to the new client
            int client_id = next_client_id++;
            for (int i = 0; i < MAX_CLIENTS; i++) {
                if (client_sockets[i] == 0) { // Find an empty slot
                    client_sockets[i] = client_fd;
                    client_ids[i] = client_id; // Store the client ID
                    FD_SET(client_fd, &master_fds);
                    if (client_fd > max_fd) max_fd = client_fd;
                    break;
                }
            }

            // Log the new client connection with their ID
            char log_message[100];
            snprintf(log_message, sizeof(log_message), "User %d connected.", client_id);
            printf("%s\n", log_message);
            log_server_activity(log_message);
        }

        // Handle incoming messages from clients
        for (int i = 0; i < MAX_CLIENTS; i++) {
            int sd = client_sockets[i];
            if (sd > 0 && FD_ISSET(sd, &read_fds)) {
                int bytes_received = recv(sd, buffer, BUFFER_SIZE, 0);
                
                // Handle client disconnection
                if (bytes_received <= 0) {
                    close(sd);
                    FD_CLR(sd, &master_fds);
                    client_sockets[i] = 0;

                    // Log the client disconnection with their ID
                    char log_message[100];
                    snprintf(log_message, sizeof(log_message), "User %d disconnected.", client_ids[i]);
                    printf("%s\n", log_message);
                    log_server_activity(log_message);

                    client_ids[i] = 0; // Reset the client ID
                } 
                // Handle received messages
                else {
                    buffer[bytes_received] = '\0';
                    encrypt_decrypt(buffer); // Decrypt received message

                    // Format the message with the user ID
                    char formatted_message[BUFFER_SIZE + 50];
                    snprintf(formatted_message, sizeof(formatted_message), "User %d: %s", client_ids[i], buffer);

                    // Log the received message
                    printf("%s\n", formatted_message);
                    log_server_activity(formatted_message);

                    // Broadcast the formatted message to all connected clients
                    for (int j = 0; j < MAX_CLIENTS; j++) {
                        if (client_sockets[j] != 0 && client_sockets[j] != sd) {
                            char broadcast_buffer[BUFFER_SIZE + 50];
                            strcpy(broadcast_buffer, formatted_message); // Copy the formatted message
                            encrypt_decrypt(broadcast_buffer); // Encrypt before sending
                            send(client_sockets[j], broadcast_buffer, strlen(broadcast_buffer), 0);
                        }
                    }
                }
            }
        }
    }

    // Close the server socket (never reaches here in an infinite loop)
    close(server_fd);
    return 0;
}
