#include "client.h"

// Function to encrypt and decrypt data using XOR operation
void encrypt_decrypt(char *data) {
    for (size_t i = 0; i < strlen(data); i++) {
        data[i] ^= XOR_KEY;
    }
}

// Function to register a new user
void register_user() {
    char username[MAX_CREDENTIALS], password[MAX_CREDENTIALS];

    FILE *file = fopen("registered_users.txt", "a");
    if (!file) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    printf("Register a new user\nUsername: ");
    fgets(username, sizeof(username), stdin);
    username[strcspn(username, "\n")] = 0;

    printf("Password: ");
    fgets(password, sizeof(password), stdin);
    password[strcspn(password, "\n")] = 0;

    encrypt_decrypt(username);
    encrypt_decrypt(password);

    fprintf(file, "%s %s\n", username, password);
    fclose(file);
    printf("User registered successfully!\n");
}

// Function to authenticate a user
int authenticate_user(const char *username, const char *password) {
    FILE *file = fopen("registered_users.txt", "r");
    if (!file) {
        perror("Error opening file");
        return 0;
    }

    char stored_username[MAX_CREDENTIALS], stored_password[MAX_CREDENTIALS];

    while (fscanf(file, "%s %s", stored_username, stored_password) == 2) {
        encrypt_decrypt(stored_username);
        encrypt_decrypt(stored_password);

        if (strcmp(stored_username, username) == 0 && strcmp(stored_password, password) == 0) {
            fclose(file);
            return 1;
        }
    }

    fclose(file);
    return 0;
}
